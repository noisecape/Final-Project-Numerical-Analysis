function [If,numVal] = trapad(a,b,fun,tol,fa,fb,numVal)
    %If = trapad(a,b,fun,tol[,fa,fb,numVal]) calcola l'integrale della funzione
    %fun utilizzando la formula dei trapezi adattiva nell'intervallo [a,b]
    %con tolleranza tol
    %INPUT:
    %a = estremo sinistro
    %b = estremo destro
    %fun = funzione da integrare
    %tol = tolleranza sull'errore
    %numVal = numero di valutazioni
    if nargin == 4
        numVal = 0;
        fa = feval(fun,a); 
        fb = feval(fun,b);
        numVal = numVal+2;
    end
    x = (a+b)/2;
    fx = feval(fun,x);
    numVal = numVal+1;
    I1 = ((b-a)*(fa+fb))/2;
    If = (I1+(b-a)*fx)/2;
    err = abs(I1-If)/3;
    if err > tol
        [t1,numVal] = trapad(a,x,fun,tol/2,fa,fx,numVal);
        [t2,numVal] = trapad(x,b,fun,tol/2,fx,fb,numVal);
        If = t1+t2;
    end
end

