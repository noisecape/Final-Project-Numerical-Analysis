function [If,numVal] = simpad(a,b,fun,tol,fa,fb,fc,numVal)
    %If = simpad(a,b,fun,tol[,fa,fb,fc,numVal]) calcola l'integrale della funzione
    %fun utilizzando la formula di Simpson adattiva nell'intervallo [a,b]
    %con tolleranza tol
    %INPUT:
    %a = estremo sinistro
    %b = estremo destro
    %fun = funzione da integrare
    %tol = tolleranza sull'errore
    %numVal = numero di valutazioni
    c = (a+b)/2;
    if nargin <= 4
        numVal = 0;
        fa = feval(fun,a); 
        fb = feval(fun,b);
        fc = feval(fun,c);
        numVal = numVal+3;
    end
    x1 = (a+c)/2;
    x2 = (b+c)/2;
    f1 = feval(fun,x1);
    f2 = feval(fun,x2);
    numVal = numVal+2;
    h = (b-a)/6;
    I1 = h*(fa+(4*fc)+fb);
    If = (0.5*h)*(fa+(4*f1)+(2*fc)+(4*f2)+fb);
    err = abs(I1-If)/15;
    if err > tol
        [t1,numVal] = simpad(a,c,fun,tol/2,fa,fc,f1,numVal);
        [t2,numVal] = simpad(c,b,fun,tol/2,fc,fb,f2,numVal);
        If = t1+t2;
    end
end

